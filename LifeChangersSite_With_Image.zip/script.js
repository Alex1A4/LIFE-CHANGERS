
// JavaScript de base, rien de spécifique pour le moment
console.log("Bienvenue sur Life Changers !");
